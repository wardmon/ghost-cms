# Reference


::: ichrome.AsyncChromeDaemon
