document.getElementsByTagName('p')[0].innerText = 'Chromewhip';
var element = document.createElement('h3');
element.innerText = 'First profile ran only!';
document.body.appendChild(element);