module.exports = {
    root: true,
    extends: [
        '@ecomfe/eslint-config'
    ],
    rules: {
        'comma-dangle': 'off'
    }
};
