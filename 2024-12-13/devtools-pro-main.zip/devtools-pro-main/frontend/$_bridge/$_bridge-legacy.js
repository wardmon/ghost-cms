import * as BridgeModule from './$_bridge.js';

self.Bridge = self.Bridge || {};
// console.log(BridgeModule);
Bridge.Main = BridgeModule.Bridge.Main;
Bridge.Model = BridgeModule.Bridge.BridgeModel;
