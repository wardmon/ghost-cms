const debug = require('debug');

module.exports = scope => debug(`devtools-pro:${scope}`);
