exports.BACKEND_JS_FILE = '/backend.js';

exports.BACKENDJS_PATH = '/backend.js';

exports.FRONTEND_PATH = 'devtools/inspector.html';
exports.BLOCKING_IGNORE_STRING = '$blocking_ignore$';
