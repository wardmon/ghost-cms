# Random User Agents
A couple of quick and dirty bash scripts using 7500 random useragents (in ua.txt) to test WAF bruteforce and flood blocking. 

# CURL
![Gif](http://i.giphy.com/3o7TKReKtMtFMVByOQ.gif "Gif")

# AB
![Gif](http://i.giphy.com/l0MYLVcGnOzagSs36.gif "Gif")

# OSX gsuhf install
Using brew: `brew install coreutil`

# OSX brew install
Using brew: `brew install ab`
