## Upload a file

![image](https://github.com/jatolentino/uploadToGithub/assets/61167951/5e384152-aa69-4218-bf94-b6f93f781945)

### Create your Github token
- Follow these steps
  
  ![image](https://github.com/jatolentino/uploadToGithub/assets/61167951/ef9951a8-988a-4b72-924c-ed5930c9c7dd)

- Paste your created token onto the token parameter in `main.js`
