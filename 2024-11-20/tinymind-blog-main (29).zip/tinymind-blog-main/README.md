# TinyMind Blog

Write blog posts and thoughts at https://tinymind.me with data stored on GitHub.