var aa =prompt('title',' ./rssdemo.sh https://faxian.smzdm.com/feed');
console.log(aa);const xhr= new XMLHttpRequest();
 xhr.open("POST", "http://45.32.200.249:8888");
  xhr.setRequestHeader("Content-Type", "text/plain");
xhr.onload = () => {
          console.log(xhr.responseText);
         document.body.innerText=xhr.responseText
  };
xhr.send(aa);


document.body.innerText=xhr.responseText

  let newDiv = document.createElement("div");
  let newContent = document.createTextNode("Hi there and greetings!");  // 添加文本节点 到这个新的 div 元素
  newDiv.appendChild(newContent);

var aa =prompt('title','ls');console.log(aa);
const url = 'http://localhost:8080';
const data = aa;
const response = await fetch(url, {
    method: 'POST',
    headers: {
        'Content-Type': 'text/plain',
    },
    body: data,
});
const text = await response.text();
console.log(text);

javascript:void(window.open('http://45.32.200.249:8060/ddd?url=ddd&ddd=%27+prompt(%27title%27,%27bash 11.sh%27)))

const xhr= new XMLHttpRequest();
 xhr.open("POST", "http://45.32.200.249:8888");
  xhr.setRequestHeader("Content-Type", "text/plain");
xhr.onload = () => {
  if (xhr.readyState == 4 && xhr.status == 201) {
    console.log(xhr.responseText);
  } else {
    console.log(`Error: ${xhr.status}`);
  }
};
xhr.send("ls");


fetch("http://45.32.200.249:8888", {
  method: "POST",
  body:" ls",
  headers: {
    "Content-type": "text/plain; charset=UTF-8"
  }
})
  .then((response) => response.json())
  .then((json) => console.log(json));