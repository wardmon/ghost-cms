

# python利用openpyxl拆分多个工作表的工作簿的方法

时间：2022-02-23 09:41:29 | 栏目：[Python代码](https://codeinn.net/2020/m/ruanjianbiancheng/python/) | 点击：次

实现按目录拆分工作簿，源数据如下图

![](https://codeinn.net/artimg/171017_1.png?2019827113342)

按目录拆分成N个文件。

![](https://codeinn.net/artimg/171017_2.png?2019827113357)

上代码，没有找是否有整个sheet 复制的，先逐个cell复制解决问题。：

# encoding: utf-8
"""
@author: 陈年椰子
@contact: hndm@qq.com
@version: 1.0
@file: Split_Xls.py
@time: 2019/9/24 0028 15:04
说明
"""
def Split_Xls(xls_file):
  from openpyxl import load_workbook
  from openpyxl import Workbook
 
  wb = load_workbook(xls_file)
  sheet_list = wb.sheetnames
  print(sheet_list)
  a_sheet = wb['目录']
  for i in range(3,6):
    sheet_name = a_sheet['B{}'.format(i)].value
    if sheet_name is None:
      break
    if sheet_name == '':
      break
    sr_sheet = wb[sheet_name]
    new_file_name = "{}.xlsx".format(sheet_name)
    print(sheet_name)
    wb_tg = Workbook()
    ws = wb_tg.active
    ws.title = sheet_name
 
    # 两个for循环遍历整个excel的单元格内容
    for i, row in enumerate(sr_sheet.iter_rows()):
      for j, cell in enumerate(row):
        # print(i,j,cell.value)
        ws.cell(row=i + 1, column=j + 1, value=cell.value)
    wb_tg.save(new_file_name)
    wb_tg.close()
  wb.close()
 
 
 
def Split_Xls2(xls_file):
  # 这个是通过删除其他的工作表，只留下要保存的工作表，这样就可以整个表复制，包括样式，过程曲折，但能达到效果。
  from openpyxl import load_workbook
  wb = load_workbook(xls_file)
  sheet_list = wb.sheetnames
  print(sheet_list)
  work_list = []
  a_sheet = wb['目录']
  for i in range(3,6):
    sheet_name = a_sheet['B{}'.format(i)].value
    if sheet_name is None:
      break
    if sheet_name == '':
      break
    work_list.append(sheet_name)
  wb.close()
 
  for sheet_name in work_list:
    new_file_name = "{}.xlsx".format(sheet_name)
    print('处理工作表', sheet_name, '\t保存文件', new_file_name)
    wb = load_workbook(xls_file)
    # print(wb.sheetnames)
    for del_sheet in sheet_list:
      if del_sheet != sheet_name:
        # print('del',del_sheet)
        wb.remove(wb[del_sheet])
    wb.save(new_file_name)
    wb.close()
 
 
Split_Xls2('test.xlsx')

#### 您可能感兴趣的文章:

-   [Python实现蒙特卡洛算法小实验过程详解](https://codeinn.net/misctech/8551.html "Python实现蒙特卡洛算法小实验过程详解")
-   [python实现俄罗斯方块小游戏](https://codeinn.net/misctech/13103.html "python实现俄罗斯方块小游戏")
-   [Python使用cookielib模块操作cookie的实例教程](https://codeinn.net/misctech/31379.html "Python使用cookielib模块操作cookie的实例教程")
-   [Python 基于wxpy库实现微信添加好友功能(简洁)](https://codeinn.net/misctech/11166.html "Python 基于wxpy库实现微信添加好友功能(简洁)")
-   [python中单下划线_的常见用法总结](https://codeinn.net/misctech/25631.html "python中单下划线_的常见用法总结")

**相关文章**

-   11-09[将tensorflow的ckpt模型存储为npy的实例](https://codeinn.net/misctech/20587.html "将tensorflow的ckpt模型存储为npy的实例")
-   11-06[python实现下载文件的三种方法](https://codeinn.net/misctech/19692.html "python实现下载文件的三种方法")
-   01-03[在ubuntu16.04中将python3设置为默认的命令写法](https://codeinn.net/misctech/40079.html "在ubuntu16.04中将python3设置为默认的命令写法")
-   10-21[python 将print输出的内容保存到txt文件中](https://codeinn.net/misctech/14541.html "python 将print输出的内容保存到txt文件中")
-   11-27[Python简单进程锁代码实例](https://codeinn.net/misctech/26686.html "Python简单进程锁代码实例")

-   [JQuery](https://codeinn.net/2020/m/wangyeqianduan/jquery/)
-   [VUE](https://codeinn.net/2020/m/wangyeqianduan/vue/)
-   [AngularJS](https://codeinn.net/2020/m/wangyeqianduan/angularjs/)
-   [MSSql](https://codeinn.net/2020/m/shujuku/mssql/)
-   [MySQL](https://codeinn.net/2020/m/shujuku/mysql/)
-   [MongoDB](https://codeinn.net/2020/m/shujuku/MongoDB/)
-   [Redis](https://codeinn.net/2020/m/shujuku/redis/)
-   [Linux](https://codeinn.net/2020/m/fuwuqi/linux/)
-   [Tomcat](https://codeinn.net/2020/m/fuwuqi/tomcat/)
-   [Nginx](https://codeinn.net/2020/m/fuwuqi/nginx/)

-   [网站首页](https://codeinn.net/2020/m/)
-   [广告投放](javascript:;)
-   [联系我们](javascript:;)
-   [版权申明](javascript:;)
-   [联系站长](http://wpa.qq.com/msgrd?v=3&uin=914707363&site=qq&menu=yes)

[返回首页](https://codeinn.net/2020/m)

Copyright © 2022 代码驿站 版权所有