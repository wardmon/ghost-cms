https://tinymind.me/editor?type=thought&id=1728533705861
https://beej.us/guide/
https://github.com/wardmon/tinymind-blog/archive/refs/heads/main.zip
https://nekonull.me/posts/llm_x_bookmark/
https://github.com/wardmon/osmosmemod/raw/refs/heads/main/README.md
https://oneimgai.com/#1
fre321.com/DATA/AppData/jackett/config
[Untitled (wardmon.github.io)](https://wardmon.github.io/jupyterlite/notebooks/?path=Untitled.ipynb)
h https://sshwifty-demo.nirui.org/
reqbin.com
h
[1111111](/1111111.md)
hj
h
https://github.com/wardmon/notehubdemo/archive/refs/heads/main.zip




h
curl 'https://www.commandlinefu.com/commands/togglefavourite'  -H 'Cookie: _ga=GA1.2.898916099.1726720470; PHPSESSID=0i4no8f77ldidjdccgnmr7mo13; _gid=GA1.2.1241127667.1728880884; remember=AeW8%2FNadWsMtSnSY%2FXQUaWGb3JanhIVVUlCi2eJkCD5x62Z%2BM4glrl3WoEecR%2BFCBZ7zY%2FJmuUCWjQjFUVgB%2Bw%3D%3D; __gads=ID=f193cd5eb4c7d2c0:T=1726720467:RT=1728902545:S=ALNI_MZONJf-4rKyIRuOh95NT0hlm_JX_A; __gpi=UID=00000ef2503b6142:T=1726720467:RT=1728902545:S=ALNI_Mbs6CsGlGmTcVLy1Uec08y9oYZNxg; __eoi=ID=6101c73cb9125e4e:T=1726720467:RT=1728902545:S=AA-AfjbVJDsU2KSNjBUqcn_CrqKN; ci_session=a%3A6%3A%7Bs%3A10%3A%22session_id%22%3Bs%3A32%3A%22b94e2cbb35e3057e23f6f2d7f8ebfa73%22%3Bs%3A10%3A%22ip_address%22%3Bs%3A9%3A%2210.0.0.71%22%3Bs%3A10%3A%22user_agent%22%3Bs%3A50%3A%22Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWeb%22%3Bs%3A13%3A%22last_activity%22%3Bs%3A10%3A%221728902757%22%3Bs%3A9%3A%22signed-in%22%3Bs%3A1%3A%221%22%3Bs%3A7%3A%22user-id%22%3Bs%3A6%3A%22103501%22%3B%7D0db71a23d15bdaad1d7035c8476fe1b5' -v  --data-raw 'id=5329&_='
h
 python copyparty-sfx.py -a wd:ubuntu -v .::r:rw,wd
h
h
h
h
ontouchdo(){ while :; do a=$(stat -c%Y "$1"); [ "$b" != "$a" ] && b="$a" && sh -c "$2"; sleep 1; done }

cat <<.>> demo.txt
sed -i '1s/^/text to prepend\n/' file1
echo "text to prepend" | cat - file
Recover a deleted file
grep -a -B 25 -A 100 'some string in the file' /dev/sda1 > results.txt
h
echo "this is a test" | sed 's/.*/\L&/; s/[a-z]*/\u&/g'
h
https://kkgithub.com/screego/server
https://app.screego.net/?room=loving-scarlet-koala
https://vdaily.huguotao.com/weekly/atom.xml
https://github.com/headllines/hackernews-weekly/issues
https://nothing.mvze.net/
https://james2doyle.github.io/simplebinder/
https://github.com/voronianski/esnextbin
https://wzrd.in/
https://esnextb.in/?gist=b7e541a42c7c1218cad6





awk 'BEGIN {for(i=1;i<=100;i++)sum+=i}; END {print sum}' /dev/null
for i in *; do mv $i prependtext$i; done

 echo 'aaaaaaa' | awk '{print toupper(substr($0,1,1))substr($0,2);}'


about:blank

javascript:{let s=document.createElement('script');s.src=prompt('Script location:');document.body.appendChild(s);}void(0);

javascript:{let s=document.createElement('script');s.type='text/javascript';s.textContent=prompt('injectandrun:js,function:');document.body.appendChild(s);}void(0);

  <meta http-equiv="Refresh" content="5;url=https://tinymind.me/editor?type=thought&id=1728533705861" />

        <script language="JavaScript">
function myrefresh()
{
window.location.reload();
   window.location ="https://tinymind.me/editor?type=thought&id=1728533705861"
}
setTimeout('myrefresh()',1000); //指定1秒刷新一次
</script>










